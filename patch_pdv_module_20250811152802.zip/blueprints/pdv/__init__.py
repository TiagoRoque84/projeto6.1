from flask import Blueprint
pdv_bp = Blueprint('pdv', __name__, template_folder='../../templates')
