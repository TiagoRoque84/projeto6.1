
import os
from functools import wraps
from flask import request, redirect, url_for, flash, current_app
from flask_login import current_user
from werkzeug.utils import secure_filename

ALLOWED = {"png","jpg","jpeg","pdf"}

def admin_required(f):
    @wraps(f)
    def _wrap(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role != "admin":
            flash("Acesso restrito ao administrador.", "danger")
            return redirect(url_for("main.index"))
        return f(*args, **kwargs)
    return _wrap

def save_file(file_storage, subdir="uploads"):
    if not file_storage: return None
    fn = secure_filename(file_storage.filename or "")
    ext = fn.rsplit(".",1)[-1].lower() if "." in fn else ""
    if ext not in ALLOWED:
        flash("Arquivo não permitido.", "danger")
        return None
    base = current_app.config.get("UPLOAD_FOLDER","uploads")
    dest_dir = os.path.join(base, subdir)
    os.makedirs(dest_dir, exist_ok=True)
    path = os.path.join(dest_dir, fn)
    file_storage.save(path)
    return path
