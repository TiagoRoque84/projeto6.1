
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
import os
from datetime import date

styles = getSampleStyleSheet()
H1 = ParagraphStyle('H1', parent=styles['Heading1'], fontSize=16, spaceAfter=8)
N = styles['Normal']

def _s(v): return "" if v is None else str(v)

def employee_pdf(buffer, app, e):
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm, topMargin=1.5*cm, bottomMargin=1.5*cm)
    elems=[]; elems.append(Paragraph(f"Ficha do Colaborador - #{e.id}", H1))
    if e.foto_path:
        try:
            photo_abs = os.path.join(app.root_path, e.foto_path)
            elems.append(Image(photo_abs, width=4*cm, height=4.8*cm, hAlign='RIGHT'))
        except Exception: pass
    data=[
        ["Nome", _s(e.nome), "Empresa", _s(e.company.razao_social if e.company else "")],
        ["Função", _s(e.funcao.nome if e.funcao else ""), "Ativo", "Sim" if e.ativo else "Não"],
        ["CPF", _s(e.cpf), "RG", _s(e.rg)],
        ["Nascimento", _s(e.data_nascimento), "Gênero", _s(e.genero)],
        ["Estado civil", _s(e.estado_civil), "Admissão", _s(e.data_admissao)],
        ["Salário (R$)", _s(e.salario), "Jornada", _s(e.jornada)],
        ["Telefone", _s(e.fone), "Celular", _s(e.celular)],
        ["E-mail", _s(e.email), "", ""],
        ["Endereço", f"{_s(e.logradouro)}, {_s(e.numero)} {_s(e.complemento)}", "CEP", _s(e.cep)],
        ["Bairro/Cidade/UF", f"{_s(e.bairro)} / {_s(e.cidade)} / {_s(e.uf)}", "", ""],
        ["Banco", _s(e.banco), "Agência/Conta", f"{_s(e.agencia)} / {_s(e.conta)}"],
        ["Tipo de conta", _s(e.tipo_conta), "PIX", f"{_s(e.pix_tipo)}: {_s(e.pix_chave)}"],
        ["ASO", _s(e.aso_tipo), "Validade", _s(e.aso_validade)],
        ["CNH", _s(e.cnh), "CNH Validade", _s(e.cnh_validade)],
        ["Toxicológico", "", "Validade", _s(e.exame_toxico_validade)],
    ]
    table = Table(data, colWidths=[3.5*cm,8.5*cm,3.5*cm,4.5*cm])
    table.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.25,colors.grey),('FONTSIZE',(0,0),(-1,-1),9)]))
    elems.append(table); elems.append(Spacer(1,0.5*cm)); elems.append(Paragraph(f"Gerado em {date.today().strftime('%d/%m/%Y')}", N))
    doc.build(elems)

def company_pdf(buffer, app, c):
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm, topMargin=1.5*cm, bottomMargin=1.5*cm)
    elems=[Paragraph(f"Ficha da Empresa - #{c.id}", H1)]
    data=[
        ["Razão Social", _s(c.razao_social)],
        ["Nome Fantasia", _s(c.nome_fantasia)],
        ["CNPJ", _s(c.cnpj)],
        ["Inscrição Estadual", _s(c.inscricao_estadual)],
        ["Endereço", f"{_s(c.logradouro)}, {_s(c.numero)} {_s(c.complemento)}"],
        ["Bairro/Cidade/UF", f"{_s(c.bairro)} / {_s(c.cidade)} / {_s(c.uf)}"],
        ["CEP", _s(c.cep)],
        ["Status", "Ativa" if c.ativa else "Inativa"],
        ["Emails alerta", _s(c.alert_email)],
        ["WhatsApp alerta", _s(c.alert_whatsapp)],
    ]
    table = Table(data, colWidths=[5*cm,12*cm]); table.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.25,colors.grey),('FONTSIZE',(0,0),(-1,-1),10)]))
    from reportlab.platypus import Spacer
    elems += [table, Spacer(1,0.5*cm), Paragraph(f"Gerado em {date.today().strftime('%d/%m/%Y')}", N)]
    doc.build(elems)

def documents_pdf(buffer, app, docs, titulo):
    from datetime import date as _d
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=1.2*cm, rightMargin=1.2*cm, topMargin=1.2*cm, bottomMargin=1.2*cm)
    elems=[Paragraph(titulo, H1)]
    data=[["Empresa","Tipo","Descrição","Número","Expedição","Vencimento","Dias","Status"]]
    for d in docs:
        dias = ""
        if d.data_vencimento:
            dias = (d.data_vencimento - _d.today()).days
        data.append([_s(d.company.razao_social if d.company else ""), _s(d.tipo.nome if d.tipo else ""), _s(d.descricao), _s(d.numero), _s(d.data_expedicao), _s(d.data_vencimento), _s(dias), _s(d.status)])
    table = Table(data, colWidths=[4*cm,3*cm,5*cm,2.5*cm,2.5*cm,2.5*cm,1.5*cm,2.5*cm], repeatRows=1)
    table.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.25,colors.grey),('BACKGROUND',(0,0),(-1,0),colors.whitesmoke),('FONTSIZE',(0,0),(-1,-1),9)]))
    from reportlab.platypus import Spacer
    elems += [table, Spacer(1,0.3*cm), Paragraph(f"Total: {len(docs)}", N)]
    doc.build(elems)
