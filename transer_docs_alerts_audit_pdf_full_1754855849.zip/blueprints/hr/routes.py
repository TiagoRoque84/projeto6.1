
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file, current_app
from flask_login import login_required
from extensions import db
from models import Employee, Company, Funcao
from forms import EmployeeForm, FuncaoForm
from utils import save_file
from audit import log_action
from pdf_reports import employee_pdf
import io, requests

hr_bp = Blueprint("rh", __name__, template_folder='../../templates/hr')

@hr_bp.route("/colaboradores")
@login_required
def employees():
    q = request.args.get("q","").strip()
    ativo = request.args.get("ativo","")
    query = Employee.query
    if q:
        like = f"%{q}%"
        query = query.filter(Employee.nome.ilike(like))
    if ativo in ("1","0"):
        query = query.filter_by(ativo=(ativo=="1"))
    items = query.order_by(Employee.nome).all()
    return render_template("hr/employees_list.html", items=items, q=q, ativo=ativo)

@hr_bp.route("/colaboradores/new", methods=["GET","POST"])
@login_required
def employees_new():
    form = EmployeeForm()
    form.company_id.choices = [(0,"-")] + [(c.id, c.razao_social) for c in Company.query.order_by(Company.razao_social)]
    form.funcao_id.choices = [(0,"-")] + [(f.id, f.nome) for f in Funcao.query.order_by(Funcao.nome)]
    if form.validate_on_submit():
        e = Employee()
        for f in form:
            if hasattr(e, f.name):
                v = f.data
                if f.name in ("company_id","funcao_id") and v==0: v=None
                setattr(e, f.name, v)
        if form.foto.data:
            e.foto_path = save_file(form.foto.data, "fotos")
        db.session.add(e); db.session.commit()
        log_action("create","Employee", e.id, {"nome": e.nome})
        flash("Colaborador criado.", "success")
        return redirect(url_for("rh.employees"))
    return render_template("hr/employee_form.html", form=form, title="Novo Colaborador")

@hr_bp.route("/colaboradores/<int:emp_id>/edit", methods=["GET","POST"])
@login_required
def employees_edit(emp_id):
    e = Employee.query.get_or_404(emp_id)
    form = EmployeeForm(obj=e)
    form.company_id.choices = [(0,"-")] + [(c.id, c.razao_social) for c in Company.query.order_by(Company.razao_social)]
    form.funcao_id.choices = [(0,"-")] + [(f.id, f.nome) for f in Funcao.query.order_by(Funcao.nome)]
    if form.validate_on_submit():
        for f in form:
            if hasattr(e, f.name):
                v = f.data
                if f.name in ("company_id","funcao_id") and v==0: v=None
                setattr(e, f.name, v)
        if form.foto.data:
            e.foto_path = save_file(form.foto.data, "fotos")
        db.session.commit()
        log_action("update","Employee", e.id, {"nome": e.nome})
        flash("Colaborador atualizado.", "success")
        return redirect(url_for("rh.employees"))
    return render_template("hr/employee_form.html", form=form, title="Editar Colaborador")

@hr_bp.route("/funcoes")
@login_required
def funcoes():
    items = Funcao.query.order_by(Funcao.nome).all()
    return render_template("hr/funcoes_list.html", items=items)

@hr_bp.route("/funcoes/new", methods=["GET","POST"])
@login_required
def funcoes_new():
    form = FuncaoForm()
    if form.validate_on_submit():
        f = Funcao(nome=form.nome.data)
        db.session.add(f); db.session.commit()
        flash("Função criada.", "success")
        return redirect(url_for("rh.funcoes"))
    return render_template("hr/funcao_form.html", form=form)

@hr_bp.route("/colaboradores/<int:emp_id>/pdf")
@login_required
def employees_pdf(emp_id):
    e = Employee.query.get_or_404(emp_id)
    bio = io.BytesIO()
    employee_pdf(bio, current_app, e)
    bio.seek(0)
    return send_file(bio, as_attachment=True, download_name=f"colaborador_{e.id}.pdf", mimetype="application/pdf")

@hr_bp.route("/api/cep/<cep>")
@login_required
def api_cep(cep):
    try:
        r = requests.get(f"https://viacep.com.br/ws/{cep}/json/", timeout=10)
        return r.json(), r.status_code
    except Exception:
        return {"erro":True}, 400
