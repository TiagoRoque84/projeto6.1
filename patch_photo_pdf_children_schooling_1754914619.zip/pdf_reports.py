
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from datetime import date as _date
import os

styles = getSampleStyleSheet()
H1 = ParagraphStyle('H1', parent=styles['Heading1'], fontSize=16, spaceAfter=8)
N = styles['Normal']

def _s(v): return "" if v is None else str(v)
def P(v): return Paragraph(_s(v), N)

def _abs_upload_path(app, rel):
    if not rel: return None
    rel = str(rel).replace('\\','/').lstrip('/')
    if rel.startswith('uploads/'): rel = rel[len('uploads/'):]
    return os.path.join(app.root_path, app.config.get('UPLOAD_FOLDER','uploads'), rel)

def employee_pdf(buffer, app, e):
    doc = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm, topMargin=1.5*cm, bottomMargin=1.5*cm)
    elems=[]
    title = Paragraph(f"Ficha do Colaborador - #{e.id}", H1)
    photo_flow = None
    if e.foto_path:
        try:
            photo_abs = _abs_upload_path(app, e.foto_path)
            if photo_abs and os.path.exists(photo_abs):
                photo_flow = Image(photo_abs, width=3.0*cm, height=4.0*cm)  # 3x4 cm
        except Exception:
            photo_flow = None
    header = Table([[title, photo_flow]], colWidths=[13.0*cm, 4.0*cm])
    header.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP')]))
    elems.append(header); elems.append(Spacer(1,0.3*cm))

    data=[
        ["Nome", P(e.nome), "Empresa", P(e.company.razao_social if e.company else "")],
        ["Função", P(e.funcao.nome if e.funcao else ""), "Ativo", P("Sim" if e.ativo else "Não")],
        ["CPF", P(e.cpf), "RG", P(e.rg)],
        ["Nascimento", P(e.data_nascimento), "Gênero", P(e.genero)],
        ["Estado civil", P(e.estado_civil), "Admissão", P(e.data_admissao)],
        ["Salário (R$)", P(e.salario), "Jornada", P(e.jornada)],
        ["Telefone", P(e.fone), "Celular", P(e.celular)],
        ["E-mail", P(e.email), "", ""],
        ["Filho < 14", P("Sim" if getattr(e,'filho_menor14',None) else ("Não" if getattr(e,'filho_menor14',None) is not None else "")), "Escolaridade", P(getattr(e,'escolaridade', ""))],
        ["Endereço", P(f"{_s(e.logradouro)}, {_s(e.numero)} {_s(e.complemento)}"), "CEP", P(e.cep)],
        ["Bairro/Cidade/UF", P(f"{_s(e.bairro)} / {_s(e.cidade)} / {_s(e.uf)}"), "", ""],
        ["Banco", P(e.banco), "Agência/Conta", P(f"{_s(e.agencia)} / {_s(e.conta)}")],
        ["Tipo de conta", P(e.tipo_conta), "PIX", P(f"{_s(e.pix_tipo)}: {_s(e.pix_chave)}")],
        ["ASO", P(e.aso_tipo), "Validade", P(e.aso_validade)],
        ["CNH", P(e.cnh), "CNH Validade", P(e.cnh_validade)],
        ["Toxicológico", "", "Validade", P(e.exame_toxico_validade)],
    ]
    table = Table(data, colWidths=[3.2*cm,7.8*cm,3.2*cm,3.8*cm])
    table.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.25,colors.grey),('FONTSIZE',(0,0),(-1,-1),9),('VALIGN',(0,0),(-1,-1),'TOP')]))
    elems.append(table); elems.append(Spacer(1,0.5*cm))
    elems.append(Paragraph(f"Gerado em {_date.today().strftime('%d/%m/%Y')}", N))
    doc.build(elems)
