
@companies_bp.route("/api/cnpj/<cnpj>")
@login_required
def api_cnpj(cnpj):
    try:
        import requests
        r = requests.get(f"https://brasilapi.com.br/api/cnpj/v1/{cnpj}", timeout=10)
        if r.status_code==200:
            d = r.json()
            out = {
                "razao_social": d.get("razao_social") or d.get("razao_social_nome_empresarial") or "",
                "nome_fantasia": d.get("nome_fantasia") or d.get("nome_fantasia_empresarial") or "",
                "cep": (d.get("cep") or "").replace("-", ""),
                "logradouro": (d.get("descricao_tipo_logradouro") or "") + " " + (d.get("logradouro") or ""),
                "bairro": d.get("bairro") or d.get("bairro_distrito") or "",
                "cidade": d.get("municipio") or d.get("cidade") or "",
                "uf": d.get("uf") or "",
                "numero": d.get("numero") or "",
                "complemento": d.get("complemento") or "",
            }
            return out
    except Exception:
        pass
    return {"erro": True}, 400
